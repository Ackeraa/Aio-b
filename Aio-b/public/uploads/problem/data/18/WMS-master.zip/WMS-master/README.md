# WMS
基于SSM框架的仓库管理系统

# 运行环境
jdk1.8<br>
tomcat8.0<br>
mysql5.7<br>

# 登录账号
账号：1001<br>
密码：123456<br>

# 联系方式
有任何部署问题，请联系邮箱（付费）
wenkang_zeng@outlook.com

## 部分截图

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE1.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/MWS-%E6%88%AA%E5%9B%BE2.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE3.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE4.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE5.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE7.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE8.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE8.PNG)

![](https://raw.githubusercontent.com/KEN-LJQ/MarkdownPics/master/Resource/2017-3-9/WMS-%E6%88%AA%E5%9B%BE9.PNG)


